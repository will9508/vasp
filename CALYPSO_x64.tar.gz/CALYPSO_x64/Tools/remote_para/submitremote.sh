#!/bin/sh

server='sxc@10.60.36.168'
port='4444'

cdir=`python -c "import os;print os.popen('pwd').read().split('/')[-1],"`

caldir='paratest/'$cdir

cat > remotesub.py << EOF
#!/usr/bin/env python
import os
import time

while True:
    id = os.popen('sh remote.sh 2>/dev/null | tail -n -1').read().split('.')[0]
    if len(id.strip()) != 0:
        break
    else:
        time.sleep(2)

while True:
    ids = []
    while True:
        statt = os.popen('''ssh -p $port $server qstat 2>/dev/null''').read()
        if len(statt.strip()) != 0:
            break
        else:
            time.sleep(2)
    stat = statt.split('\n')
    for line in stat[2:-1]:
        idd = line.split('.')[0]
        ids.append(idd)

    if id not in ids:
        while True:
            s1 = os.system('scp -P $port $server:~/$caldir/OUTCAR . 2>/dev/null')
            s2 = os.system('scp -P $port $server:~/$caldir/CONTCAR . 2>/dev/null')
            if s1 == 0 and s2 == 0:
                break
            else:
                time.sleep(2)
        break

    time.sleep(5)

EOF

cat > remote.sh << EOF
#!/bin/sh
ssh -T -p $port $server mkdir -p $caldir
scp -P $port vasp.pbs writekp.py INCAR_* POTCAR POSCAR $server:~/$caldir
ssh -T -t -p $port $server << !
cd $caldir
qsub vasp.pbs
!
EOF

sed '/Selective/d' POSCAR >> ini
python remotesub.py
sed -i '/Selective/d' CONTCAR
python contcar.py
python getenth.py >> opt 
cat CONTCAR >> opt

