#!/usr/bin/env python  
import os
import re
osawk ='''awk '/energy  without entropy/ {print $4}' OUTCAR | tail -1'''
b=os.popen(osawk).read() 
a = b[0:-1]
if re.match(r'^-?(\d+)\.(\d+)', a):
    print a
else:
    print 610612509
