#!/bin/sh
#mpdboot
mpiexec -n 12 ./vasp > log 2>/dev/null
