#!/usr/bin/env python
'''
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!> Purpose:                                                     <!
!> Discription:                                                 <!
!> Note:                                                        <!
!> Date of creation: Fri Aug 30 14:10:00 CST 2013               <!
!> Record of revisions:                                         <!
!>   Date     Programmer  platform    Description of changes    <!
!> ========== ========== ========== ============================<!
!>            Lu Shaohua  Linux,i&g    Original, on subroutine  <!   
!> Usage: python ' + os.path.basename(sys.argv[0]) + ' Method'  <!  
!> Supported 3rd party relaxation code: VASP, DFTB+'            <!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
'''
import sys, os, subprocess
def surf_vasp():
	print 'vasp run'
	'''trim selective columns in CONTCAR'''
	subprocess.call(['cp','POSCAR','CONTCAR'])
	for i in range(2):
		#subprocess.call(['cat', 'INCAR-'+str(i+1)])
		#subprocess.call(['cat', 'KPOINTS-'+str(i+1)])
		#subprocess.call(['cat', 'SD-'+str(i+1)])
		#subprocess.call(['cat', 'POSCAR-'+str(i+1)])
		#merge CONTCAR and SD-i to POSCAR
		try:
			fp=open('POSCAR','w') 
			fc=open('CONTCAR','r')
			fs=open('SD-'+str(i+1),'r')
			
			conlist = []
			sdlist = []
			
			yy = []
			for each_line in fc:
				conlist.append(each_line)
			for each_line in fs:
				sdlist.append(each_line)
			
			trim=False
			poscnt = 0
			totcnt = len(sdlist)
			for xx in conlist:
				if not trim:
					fp.write(xx)
				else:
					#print type(xx)
					yy=xx.split()
					#print ''.join(yy)
					#print yy
					#sd=sdlist[poscnt]
					a='    '.join(yy[0:3]) + '   ' + sdlist[poscnt]
					fp.write(a)
					poscnt=poscnt+1
					if poscnt == totcnt:
						trim=False
					
				if xx.strip() == 'Direct':
					trim=True
				
		except:# IOError as ierr:
			print 'File error: ' + str(ierr)
		#finally:
		fp.close()
		fc.close()
		fs.close()
		#subprocess.call(['cp', 'POSCAR', 'POSCAR-' + str(i+1)])
		
		subprocess.call(['cp','INCAR-'+str(i+1),'INCAR'])
		subprocess.call(['cp','KPOINTS-'+str(i+1),'KPOINTS'])
		subprocess.call(['sh','submit.sh'])
		
	
	
	#print os.getcwd()
	
	
def surf_dftb():
	#print 'dftb run'
	#print os.getcwd()
	for lp_i in range(2):
		subprocess.call(['cp', 'dftb_in.hsd-'+str(lp_i+1), 'dftb_in.hsd'])
		subprocess.call(['sh','submit.sh'])
		if os.path.exists('geom.out.gen') == True:
			subprocess.call(['cp', 'geom.out.gen', 'dftb.gen'])
		else:
			pass
def surf_gulp():
	subprocess.call(['sh','submit.sh'])
#
#
if __name__ == '__main__':
	#cd to the script directory
	curdir=os.getcwd() 
	os.chdir(os.path.abspath(os.path.dirname(sys.argv[0])))
	
	#Relax code
	try:
		relaxcode = sys.argv[1].strip().upper()
	except:
		relaxcode = ''
	
	
	if relaxcode == 'VASP':
		surf_vasp()
	elif relaxcode == 'DFTB+':
		surf_dftb()
	elif relaxcode == 'GULP':
		surf_gulp()
	else:
		print 'Do nothing.'
	
	subprocess.call(['touch','.done.'])
	
	#Swith back to exectute directory
	os.chdir(curdir)
