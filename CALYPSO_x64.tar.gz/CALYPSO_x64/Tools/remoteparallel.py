#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: Li Zhu < zhulipresent@gmail.com >


import os
import sys
import glob
import threading
import time
import random
import math

def todo(poscar):
    # run vasp
    global full
    global poscars
    for i in range(0, len(todolist)):
        if todolist[i] == 0:
            todolist[i] = 1
            runvasp(poscars[i])
            break
    return 0

def writekp(caldir, kgrid):
    '''''''''
    
    Arguments:
    - `caldir`: dir of calculation
    - `kgrid` : Kmesh
    '''''''''
    # read the lattice

    def dot(x, y):
        return x[0]*y[0] + x[1]*y[1] + x[2]*y[2]

    def cross(x, y):
        z1 = x[1]*y[2] - x[2]*y[1]
        z2 = x[2]*y[0] - x[0]*y[2]
        z3 = x[0]*y[1] - x[1]*y[0]
        return [z1, z2, z3]

    def kmf(kgrid, gi):
        kd = int(gi/kgrid/2.0/math.pi)
        if kd == 0: kd = 1
        dd = gi/kd/2.0/math.pi
        if dd >= kgrid:
            for i in range(0, 10):
                kd += i
                dd = gi/kd/2.0/math.pi
                if dd <= kgrid: break
        return kd 
                    
    f = open(caldir+'/POSCAR')
    pp = []
    try:
        for line in f:
            pp.append(line.split())
    finally:
        f.close()
    l = []
    for item in pp[2:5]:
        l.append(map(float, item))
    # real Lattice Parameters
    ra = math.sqrt(l[0][0]**2 + l[0][1]**2 + l[0][2]**2)
    rb = math.sqrt(l[1][0]**2 + l[1][1]**2 + l[1][2]**2)
    rc = math.sqrt(l[2][0]**2 + l[2][1]**2 + l[2][2]**2)

    c = cross(l[1], l[2])
    volume = dot(l[0], c)
    g = []
    g1 = [ 2.0 * math.pi * item / volume for item in c]
    c = cross(l[2], l[0])
    g2 = [ 2.0 * math.pi * item / volume for item in c]
    c = cross(l[0], l[1])
    g3 = [ 2.0 * math.pi * item / volume for item in c]
    g = [g1, g2, g3]
    
    rl = []
    for i in range(0, 3):
        rl.append(math.sqrt(dot(g[i],g[i])))
    kmesh = []
    for i in range(0, 3):
        kmesh.append(kmf(kgrid, rl[i]))
    f = open(caldir + '/KPOINTS', 'w')
    f.write('A\n0\nG\n')
    f.write('%2d %2d %2d\n' % tuple(kmesh))
    f.write('%2d %2d %2d\n' % (0,0,0))
    # debug
    print 'volume: ', volume
    print 'rl ', rl
    print 'kp ', kmesh
    
def runvasp(poscar):
    global caldirs
    global incars
    global occupdir
    for i in range(0, len(occupdir)):
        if occupdir[i] == 0:
            caldir = caldirs[i]
            break
    os.system('cp ' + poscar + ' ' + caldir + '/iPOSCAR')
    os.system('cp ' + poscar + ' ' + caldir + '/POSCAR')
    num_of_opti = len(incars)
    
    for iopt in range(0, num_of_opti):
        os.system('cp ' + incars[iopt] + caldir + '/INCAR')
        os.system('cp POTCAR ' + caldir)
        writekp(caldir, kgrids[iopt])
        if pcr.normPOSCAR():
            # os.system('cd ' + caldir +';' + vaspcmd)
            status = rvasp(caldir)
        else:
            break
        os.system('cd ' + caldir + '; cp CONTCAR POSCAR')

    os.system(''' sed -i '/Selective/d' ''' + caldir + '/CONTCAR')
    os.system(''' sed -i '/Selective/d' ''' + caldir + '/iPOSCAR')
    ccr.icontcar()
    
    return 0

def rbackvasp(caldir):
    def calvasp(caldir):
        os.execl('/bin/sh', 'sh', '-c', 'cd ' + caldir + '; ' + vaspcmd)
    def getsonpid(fatherpid):
        fpid = fatherpid
        sonpid = []
        sonpid.append(fpid)
        while True:
            try:
                tpid = int(os.popen('''ps --ppid ''' + str(fpid) +\
                           ''' | awk 'NR>=2{print $1}' ''').read().split()[0])
            except:
                break
            sonpid.append(tpid)
            fpid = tpid
        return sonpid
    global maxtime
    p = Process(target=calvasp)
    p.start()
    starttime = time.time()
    fpid = p.pid
    allpid = getsonpid(fpid)
    status = 1
    while True:
        time.sleep(5)
        endtime = time.time()
        caltime = endtime - starttime
        if caltime >= maxtime: 
            killcmd = 'kill -9 ' + ' '.join(map(str, allpid)) + '2 >/dev/null'
            os.system(killcmd)
            status = 0
            break
    return status

def rvasp(caldir, i):
    global plist
    time.sleep(2)
    while len(plist) > 0:
        try:
            time.sleep(i+1)
            print '''cp ''' + plist[0] + '''  ''' + caldir + '''/POSCAR'''
            print 
            os.system('''cp ''' + plist[0] + '''  ''' + caldir + '''/POSCAR''')
            del(plist[0])
            print plist
            os.system('''cd ''' + caldir + '''; sh submitremote.sh''')
        except:
            #print 'f**, error'
            return 0
    return 0

def copyfile():
    caldirs = glob.glob('caldir*')
    caldirs.sort()
    for caldir in caldirs:
        os.system('cp writekp.py getenth.py contcar.py submitremote.sh vasp.pbs INCAR_* POTCAR  ' + caldir) 
        os.system('> ' + caldir + '/ini')
        os.system('> ' + caldir + '/opt')
    return 0

def parallel():
    global plist
    poscars = glob.glob('POSCAR_*')
    poscars.sort(key=lambda x:int(x.split('_')[1]))
    plist = poscars[:]
    caldirs = glob.glob('caldir*') 
    caldirs.sort()
    print caldirs
    numthread = len(caldirs)
    runs = []
    for i in range(0, numthread):
        runs.append(threading.Thread(target=rvasp, args=(caldirs[i], i,)))
    for t in runs:
        t.start()
    for t in runs:
        t.join()
    return 0

def cpresults():
    step = sys.argv[1]
    caldirs = glob.glob('caldir*')
    for caldir in caldirs:
        os.system('cat ' + caldir + '/ini >> results/pso_ini_' + step)
        os.system('cat ' + caldir + '/opt >> results/pso_opt_' + step)
    return 0

if __name__ == '__main__':
    copyfile()
    parallel()
    cpresults()
    
