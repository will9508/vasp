export PYTHONPATH=/home/sxc/hg/calypso_dev/Tools/CALYPSO_ANALYSIS_KIT/lib/python:$PYTHONPATH
export PATH=/home/sxc/hg/calypso_dev/Tools/CALYPSO_ANALYSIS_KIT:$PATH
