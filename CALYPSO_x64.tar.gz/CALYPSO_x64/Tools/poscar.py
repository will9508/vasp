#!/usr/bin/env python
# 2010.10.28
#

import os

def normPOSCAR(caldir):
    pos = []
    f = open(caldir + '/POSCAR')

    try:
        for line in f:
            pos.append(line)
    except:
        f.close()

    lattice = []

    for item in pos[2:5]:
        try:
            lattice.append(map(float, item.split()))
        except:
            return False
            
    for item in lattice:
        if len(item) != 3: return False

    for i in range(0, 3):
        for j in range(0, 3):
            if abs(lattice[i][j]) < 2.e-3: 
                lattice[i][j] = 0.


    poscar = open(caldir + '/POSCAR', 'w')

    for item in pos[0:2]:
        poscar.write(item)

    for item in lattice:
        poscar.write("%15.8f %15.8f %15.8f\n" % tuple(item))

    for item in pos[5:]:
        poscar.write(item)
    return True

if __name__=='__main__':
    if normPOSCAR('./'):
        os.system('''echo T > optstate''')
    else:
        os.system('''cp POSCAR.bak POSCAR; 
                echo F > optstate''')
