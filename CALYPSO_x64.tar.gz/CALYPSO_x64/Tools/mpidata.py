#!/usr/bin/python
# -*- coding: utf-8 -*-
#

kgrid = [0.1, 0.06]
command = 'sh submit.sh'
numopt = 3
maxtime = 10
numthread = 4
