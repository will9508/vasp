#!/usr/bin/python 
# -*- coding: utf-8 -*-
# Author : Li Zhu < zl@calypso.cn >
def read_lammps():
    try:
        f = open('relax.lammpstrj')
    except:
        return False
    
    datas = []
    try:
        for line in f:
            datas.append(line.split())
    finally:
        f.close()
    
    natom = int(datas[3][0])
    
    boxb = [map(float, xterm) for xterm in datas[5:8]]
    xlo_bound = boxb[0][0]
    xhi_bound = boxb[0][1]
    xy = boxb[0][2]
    ylo_bound = boxb[1][0]
    yhi_bound = boxb[1][1]
    xz = boxb[1][2]
    zlo_bound = boxb[2][0]
    zhi_bound = boxb[2][1]
    yz = boxb[2][2]
    
    atomt = datas[9 : 9 + natom]
    
    atoms = []
    typts = []
    for i in range(natom):
        atoms.append(map(float, atomt[i][2:]))
        typts.append(int(atomt[i][1]))
    for i in range(len(atoms)):
        for j in range(3):
            if atoms[i][j] >= 1.0: atoms[i][j] -= int(atoms[i][j])
    
    lx = xhi_bound - xlo_bound
    ly = yhi_bound - ylo_bound
    lz = zhi_bound - zlo_bound
    
    lattice = [ [ lx, 0., 0. ],
                [ xy, ly, 0. ],
                [ xz, yz, lz ]]
    
    typt = [str(typts.count(x)) for x in set(typts)]
     
    f = open('CONTCAR', 'w')
    f.write('lammps\n')
    f.write('1.0\n')
    for item in lattice:
        f.write('%12.5f %12.5f %12.5f\n' % tuple(item))
    f.write('  '.join(typt) + '\n')
    f.write('Direct\n')
    for item in atoms:
        f.write('%10.6f %10.6f %10.6f\n' % tuple(item))
    return True
     
if __name__ == '__main__':
    read_lammps()
     
     
     
     
     
     
    
    
