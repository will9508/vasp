#!/usr/bin/python
# -*- coding: utf-8 -*-

from multiprocessing import Process
import os
import time
import mpidata

def f(caldir):
    os.system("cd " + caldir + "; " + mpidata.command)

def gpid(fpid):
    time.sleep(2)
    allpid = []
    allpid.append(fpid)
    b = os.popen('ps --ppid ' + fpid).read().split('\n')
    while len(b) == 3:
        spid = b[1].split()[0]
        allpid.append(spid)
        b = os.popen('ps --ppid ' + spid).read().split('\n')
    return ' '.join(allpid)

def rvasp(caldir):
    p = Process(target=f, args=(caldir, ))
    p.start()
    start = time.time()
    apid = gpid(str(p.pid))
    while 1:
        if p.is_alive():
            end = time.time()
            if end-start < mpidata.maxtime:
                time.sleep(10)
                continue
            else:
                os.system("kill -9 " + apid)
                print 'job is killed'
                break
        else:
            break
    return 0

if __name__ == '__main__':
    rvasp('./')
