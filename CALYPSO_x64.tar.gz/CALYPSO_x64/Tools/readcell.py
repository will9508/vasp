#!/usr/bin/python -u
# -*- coding: utf-8 -*-
# Author: Li Zhu < zl@calypso.cn >

import os
def readcell():
    try:
        f = open('castep-out.cell')
    except:
        return False
    
    datas = []
    try:
        for line in f:
            datas.append(line.strip().lower())
    finally:
        f.close()
        
    l1 = datas.index("%block lattice_cart")
    l2 = datas.index("%endblock lattice_cart")
    lat = datas[l2-3 : l2]
    
    a1 = datas.index("%block positions_frac")
    a2 = datas.index("%endblock positions_frac")
    
    atom1 = datas[a1+1 : a2]
    
    atom = [item[5:] for item in atom1]
    
    symbs = [item.split()[0] for item in atom1 ]

    symb = []
    for x in symbs:
        if x not in symb:
            symb.append(x)
    typt = [str(symbs.count(x)) for x in symb]
    
    f = open('CONTCAR', 'w')
    f.write('POS\n')
    f.write('1.0\n')
    for item in lat:
        f.write(item + '\n')
    f.write('  '.join(typt) + '\n')
    f.write('Direct\n')
    for item in atom:
        f.write(item + '\n')
    f.close()
    return True
        
if __name__ == '__main__':
    if not readcell():
        print 'dafdaf'
        os.system('cp POSCAR CONTCAR')
