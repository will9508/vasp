#!/usr/bin/env python  
# _*- coding: utf-8 -*-
# Author: Li Zhu < zhulipresent@gmail.com>

import os

def pressure(caldir):
    info = os.popen('''grep external ''' + caldir + '''/OUTCAR | tail -n 1''').read().split()
    try:
        external = float(info[3])
        pullay = float(info[8])
    except:
        return False
    
    if abs(pullay - 0.0) < 1.:
        if abs(external) < 20.: 
            return True
        else:
            return False
    elif pullay < 1000.:
        if abs(external) < 50.:
            return True
        else:
            return False
    elif pullay < 10000.:
        if abs(external) < 100.:
            return True
        else:
            return False
    else:
        if abs(external) < 500.:
            return True
        else:
            return False

def outEnergy(caldir):
    f = open(caldir + "/CONTCAR")
    for i in range(0, 6):
        line = f.readline()
    try:
        natom = sum(map(int, line.split()))
    except:
        line = f.readline()
        natom = sum(map(int, line.split()))
    f.close()
    osawk = '''awk '/energy  without entropy=/ {print $4}' ''' + caldir + "/OUTCAR | tail -1"
    b = os.popen(osawk).read() 
    a = b[0:-1]
    try:
        e = float(a) / natom
    except:
        e = 610612509

    return e

def hardness():
    try:
        f = open('hardnes.dat')
    except:
        return 0
    try:
        b = f.readline()
    except:
        return 0
    try:
        h = float(b)
    except:
        return 0
    return h

def enthalpy(caldir):
    e = outEnergy(caldir)
    # h = hardness()
    print e
    return e

if __name__ == "__main__":
    enthalpy('./')

