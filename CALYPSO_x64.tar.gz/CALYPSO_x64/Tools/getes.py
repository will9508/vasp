#!/usr/bin/env python

import os

def outEnergy():
    b = os.popen('''awk '/Total =/{print $4}' siesta.out''').read()
    try:
        e = float(b)
    except:
        e = 610612509

    return e

if __name__ == "__main__":
    e = outEnergy()
    print e
