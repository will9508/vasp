#!/usr/bin/python -u
# -*- coding: utf-8 -*-
# Author: Li Zhu < zhulipresent@gmail.com >


import os
import sys
import glob
import threading

import mpidata
from writekp import writekp
from contcar import icontcar
from getenth import enthalpy
try:
    from rvasp import rvasp
    rv = True 
except:
    print '''Warning: multiprocessing is not found.\n'''
    print '''Please install mutiporcessing or python 2.6.'''
    rv = False


def smf():
    ''' split the machinefile.
    '''

    numthread = mpidata.numthread
    try:
        mf = open('machinefile')
    except:
        print 'Error: cannot open machinefile'
        exit(0)

    mfs = []
    try:
        for line in mf:
            mfs.append(line)
    finally:
        mf.close()

    cores = []
    ecore = len(mfs) / numthread
    k = 0
    for i in range(numthread):
        f = open('snodefile' + str(i+1), 'w')
        for j in range(ecore):
            f.write(mfs[k])
            k += 1
        f.close()

    for i in range(numthread):
        os.system('cp snodefile' + str(i+1) + ' caldir' + str(i+1) + '/snodefile')
        os.system('cp POTCAR caldir' + str(i+1))
    
    if os.path.exists('submit.sh'):
        for i in range(numthread):
            os.system('cp submit.sh  caldir' + str(i+1))

    return 0

def readinput():
    try:
        f = open('input.dat')
    except:
        print '''Error: input.dat'''
        exit(0)
    indata = {}
    try:
        for line in f:
            if '=' in line:
                if line.strip()[0] != '#':
                    litem = line.split('=')
                    indata[litem[0].strip()] = litem[1].strip()
    finally:
        f.close()

    try:
        mpidata.kgrid = map(float, indata['Kgrid'].split())
    except:
        mpidata.kgrid = [0.1, 0.06]

    try:
        mpidata.numopt = int(indata['NumberOfLocalOptim'])
    except:
        mpidata.numopt = 4

    try:
        mpidata.command = indata['Command']
    except:
        mpidata.command = 'sh submit.sh'

    try:
        mpidata.maxtime = int(indata['MaxTime'])
    except:
        mpidata.maxtime = 7200

    try:
        mpidata.numthread = int(indata['NumberOfParallel'])
    except:
        mpidata.numthread = 4

    return 0

def execvasp(caldir):
    #os.system('''cd ''' + caldir + '''; sh Jsub.sh''')
    os.system('''> ''' + caldir + '''/ini''')
    os.system('''> ''' + caldir + '''/opt''')
    poscars = glob.glob(caldir + '''/POSCAR_*''') 
    for pos in poscars:
        os.system('''cp ''' + pos + ''' ''' + caldir + '''/POSCAR''')
        os.system('''sed '/Selective/d' ''' + caldir + '''/POSCAR >> ''' + caldir + '''/ini''')
        for i in range(mpidata.numopt - 1):
            os.system('cp INCAR_' + str(i+1) + ' ' + caldir + '/INCAR')
            writekp(mpidata.kgrid[0], caldir)
            os.system('''cd ''' + caldir + '''; ''' + mpidata.command)
            os.system('''cp ''' + caldir + '''/CONTCAR ''' + caldir + '''/POSCAR''')
        os.system('cp INCAR_' + str(mpidata.numopt) + ' ' + caldir + '/INCAR')
        writekp(mpidata.kgrid[1], caldir)
        if rv:
            rvasp(caldir)
        else:
            os.system('''cd ''' + caldir + '''; ''' + mpidata.command)
        os.system('''sed -i '/Selective/d' ''' + caldir + '''/CONTCAR''')
        icontcar(caldir)
        enth = enthalpy(caldir)
        os.system('''echo ''' + str(enth) + ''' >> ''' + caldir + '''/opt''')
        os.system('''cat ''' + caldir + '''/CONTCAR >> ''' + caldir + '''/opt''') 
    
    return 0

def parallel():
    caldirs = glob.glob('caldir*') 
    numthread = len(caldirs)
    runs = []
    for i in range(0, numthread):
        runs.append(threading.Thread(target=execvasp, args=(caldirs[i],)))
    for t in runs:
        t.start()
    for t in runs:
        t.join()
    return 0

def cpresults():
    step = sys.argv[1]
    caldirs = glob.glob('caldir*')
    for caldir in caldirs:
        os.system('cat ' + caldir + '/ini >> results/pso_ini_' + step)
        os.system('cat ' + caldir + '/opt >> results/pso_opt_' + step)
    return 0

def jldir():
    caldirs = glob.glob('caldir*')
    poscars = glob.glob('POSCAR_*')
    acaldirs = caldirs * (len(poscars)/len(caldirs) + 1)
    i = 0
    for pos in poscars:
        os.system('cp ' + pos + '  ' + acaldirs[i])
        i += 1

    return 0

def main():
    readinput()
    smf()
    jldir()
    parallel()
    cpresults()

if __name__ == '__main__':
    main()

